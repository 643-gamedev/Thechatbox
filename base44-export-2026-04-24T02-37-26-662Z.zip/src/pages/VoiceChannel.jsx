const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import { Mic, MicOff, PhoneOff, Monitor, MonitorOff, Video, VideoOff, Users, Loader2, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser } from '@/lib/UserContext';

// We use PeerJS CDN via script tag — loaded dynamically
function loadPeerJS() {
  return new Promise((resolve) => {
    if (window.Peer) { resolve(); return; }
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
    s.onload = resolve;
    document.head.appendChild(s);
  });
}

// Derive a stable "room host" peer ID from the channel id
function getRoomPeerId(channelId) {
  return `thechatbox-vc-${channelId}`.replace(/[^a-zA-Z0-9-_]/g, '-');
}

function getUserPeerId(channelId, userId) {
  const safe = (userId || 'anon').replace(/[^a-zA-Z0-9]/g, '').slice(0, 12);
  return `tcb-${channelId.slice(0, 8)}-${safe}-${Math.random().toString(36).slice(2, 6)}`;
}

export default function VoiceChannel() {
  const { serverId, channelId } = useParams();
  const { currentUser, isGuest } = useUser();

  const { data: channels = [] } = useQuery({
    queryKey: ['channels', serverId || 'main'],
    queryFn: () => db.entities.Channel.filter({ server_id: serverId || 'main' }),
  });
  const channel = channels.find(c => c.id === channelId);

  const displayName = isGuest
    ? (currentUser?.display_name || 'Guest')
    : (currentUser?.full_name || currentUser?.email?.split('@')[0] || 'User');

  // UI state
  const [phase, setPhase] = useState('lobby'); // lobby | connecting | room
  const [micEnabled, setMicEnabled] = useState(true);
  const [camEnabled, setCamEnabled] = useState(false);
  const [screenSharing, setScreenSharing] = useState(false);
  const [error, setError] = useState('');
  const [peers, setPeers] = useState([]); // [{id, name, stream}]
  const [myStream, setMyStream] = useState(null);

  // Refs
  const peerRef = useRef(null);
  const myStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const callsRef = useRef({}); // peerId -> call
  const localVideoRef = useRef(null);

  const cleanup = useCallback(() => {
    if (myStreamRef.current) {
      myStreamRef.current.getTracks().forEach(t => t.stop());
      myStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    Object.values(callsRef.current).forEach(c => c.close());
    callsRef.current = {};
    if (peerRef.current) {
      peerRef.current.destroy();
      peerRef.current = null;
    }
    setPeers([]);
    setMyStream(null);
    setScreenSharing(false);
  }, []);

  useEffect(() => () => cleanup(), [cleanup]);

  // Show local video when stream changes
  useEffect(() => {
    if (localVideoRef.current && myStream) {
      localVideoRef.current.srcObject = myStream;
    }
  }, [myStream]);

  const addPeerStream = (id, name, stream) => {
    setPeers(prev => {
      const existing = prev.find(p => p.id === id);
      if (existing) return prev.map(p => p.id === id ? { ...p, stream } : p);
      return [...prev, { id, name, stream }];
    });
  };

  const removePeer = (id) => {
    setPeers(prev => prev.filter(p => p.id !== id));
    delete callsRef.current[id];
  };

  const callPeer = (remotePeerId, remoteName) => {
    if (!peerRef.current || !myStreamRef.current) return;
    if (callsRef.current[remotePeerId]) return;
    const call = peerRef.current.call(remotePeerId, myStreamRef.current, {
      metadata: { name: displayName },
    });
    callsRef.current[remotePeerId] = call;
    call.on('stream', stream => addPeerStream(remotePeerId, remoteName || remotePeerId, stream));
    call.on('close', () => removePeer(remotePeerId));
    call.on('error', () => removePeer(remotePeerId));
  };

  const joinRoom = async () => {
    setPhase('connecting');
    setError('');
    try {
      await loadPeerJS();

      // Get local media
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: camEnabled,
      });
      myStreamRef.current = stream;
      setMyStream(stream);
      if (!micEnabled) stream.getAudioTracks().forEach(t => t.enabled = false);

      const myId = getUserPeerId(channelId, currentUser?.email || currentUser?.guest_id);
      const peer = new window.Peer(myId, {
        host: '0.peerjs.com', port: 443, path: '/', secure: true,
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
          ]
        }
      });
      peerRef.current = peer;

      peer.on('open', (id) => {
        setPhase('room');
        // Try to connect to the "room" peer — whoever registered that id is the host
        // We use a data connection to exchange presence
        const roomId = getRoomPeerId(channelId);
        if (id !== roomId) {
          // Try to reach host
          const conn = peer.connect(roomId, { metadata: { name: displayName } });
          conn.on('open', () => {
            conn.send({ type: 'hello', name: displayName, peerId: id });
            callPeer(roomId, 'Host');
          });
          conn.on('data', (data) => {
            if (data.type === 'peers') {
              // Host sends us list of existing peers
              data.peers.forEach(p => {
                if (p.id !== id) callPeer(p.id, p.name);
              });
            }
          });
          conn.on('error', () => {
            // No host yet — try to become host
            becomeHost(peer, id, stream);
          });
        } else {
          becomeHost(peer, id, stream);
        }
      });

      peer.on('call', (call) => {
        call.answer(myStreamRef.current);
        const remoteName = call.metadata?.name || call.peer;
        call.on('stream', stream => addPeerStream(call.peer, remoteName, stream));
        call.on('close', () => removePeer(call.peer));
        callsRef.current[call.peer] = call;
      });

      peer.on('error', (err) => {
        if (err.type === 'unavailable-id') {
          // ID taken, regenerate
          peer.destroy();
          joinRoom();
        } else {
          setError(`Connection error: ${err.message || err.type}`);
        }
      });

    } catch (e) {
      setError(e.message || 'Failed to access microphone');
      setPhase('lobby');
    }
  };

  const becomeHost = (peer, id, stream) => {
    const knownPeers = [{ id, name: displayName }];
    peer.on('connection', (conn) => {
      conn.on('open', () => {
        conn.send({ type: 'peers', peers: knownPeers });
        knownPeers.push({ id: conn.peer, name: conn.metadata?.name || conn.peer });
        // Broadcast new peer to everyone else
      });
      conn.on('data', (data) => {
        if (data.type === 'hello') {
          knownPeers.push({ id: data.peerId, name: data.name });
        }
      });
    });
  };

  const leaveRoom = () => {
    cleanup();
    setPhase('lobby');
  };

  const toggleMic = () => {
    if (!myStreamRef.current) return;
    const enabled = !micEnabled;
    myStreamRef.current.getAudioTracks().forEach(t => t.enabled = enabled);
    setMicEnabled(enabled);
  };

  const toggleCam = async () => {
    if (!myStreamRef.current) return;
    const videoTracks = myStreamRef.current.getVideoTracks();
    if (camEnabled) {
      videoTracks.forEach(t => { t.enabled = false; });
      setCamEnabled(false);
    } else {
      if (videoTracks.length > 0) {
        videoTracks.forEach(t => { t.enabled = true; });
        setCamEnabled(true);
      } else {
        // Add video track
        try {
          const vs = await navigator.mediaDevices.getUserMedia({ video: true });
          const vt = vs.getVideoTracks()[0];
          myStreamRef.current.addTrack(vt);
          // Update all existing calls
          Object.values(callsRef.current).forEach(call => {
            const sender = call.peerConnection?.getSenders().find(s => s.track?.kind === 'video');
            if (sender) sender.replaceTrack(vt);
          });
          setMyStream(new MediaStream(myStreamRef.current.getTracks()));
          setCamEnabled(true);
        } catch (e) {
          setError('Camera access denied');
        }
      }
    }
  };

  const toggleScreenShare = async () => {
    if (screenSharing) {
      // Stop screen share, restore camera
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
        screenStreamRef.current = null;
      }
      setScreenSharing(false);
      // Optionally restore camera track
    } else {
      try {
        const ss = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
        screenStreamRef.current = ss;
        const screenTrack = ss.getVideoTracks()[0];
        // Replace video track in all calls
        Object.values(callsRef.current).forEach(call => {
          const sender = call.peerConnection?.getSenders().find(s => s.track?.kind === 'video');
          if (sender) sender.replaceTrack(screenTrack);
        });
        // Update local preview
        const newStream = new MediaStream([
          ...myStreamRef.current.getAudioTracks(),
          screenTrack,
        ]);
        setMyStream(newStream);
        setScreenSharing(true);
        // When user stops via browser UI
        screenTrack.onended = () => toggleScreenShare();
      } catch (e) {
        if (e.name !== 'NotAllowedError') setError('Screen share failed');
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="h-12 border-b border-border flex items-center px-4 gap-2 bg-card flex-shrink-0">
        <Mic className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm font-bold glow-subtle">{channel?.name || 'Voice Channel'}</span>
        {channel?.description && (
          <>
            <span className="text-muted-foreground text-xs">|</span>
            <span className="text-xs text-muted-foreground truncate">{channel.description}</span>
          </>
        )}
        {phase === 'room' && (
          <span className="ml-auto text-[10px] text-muted-foreground flex items-center gap-1">
            <Users className="w-3 h-3" /> {peers.length + 1} connected
          </span>
        )}
      </div>

      {/* Lobby */}
      {phase === 'lobby' && (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <div className="text-center space-y-5 max-w-sm w-full">
            <div className="space-y-2">
              <div className="text-4xl">🎙️</div>
              <h2 className="text-sm font-bold glow tracking-widest">#{channel?.name || 'voice'}</h2>
              <p className="text-[10px] text-muted-foreground">// P2P voice channel — WebRTC powered</p>
            </div>

            <div className="border border-border rounded p-4 bg-card space-y-3 text-left">
              <p className="text-[10px] tracking-widest text-muted-foreground">JOIN OPTIONS</p>
              <label className="flex items-center gap-3 cursor-pointer" onClick={() => setMicEnabled(v => !v)}>
                <div className={`w-8 h-4 rounded-full transition-colors relative ${micEnabled ? 'bg-primary' : 'bg-muted'}`}>
                  <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${micEnabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
                </div>
                <span className="text-xs">Enable microphone</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer" onClick={() => setCamEnabled(v => !v)}>
                <div className={`w-8 h-4 rounded-full transition-colors relative ${camEnabled ? 'bg-primary' : 'bg-muted'}`}>
                  <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${camEnabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
                </div>
                <span className="text-xs">Enable camera</span>
              </label>
              <p className="text-[10px] text-muted-foreground">Joining as: <span style={{ color: '#39FF14' }}>{displayName}</span></p>
            </div>

            {error && <p className="text-xs text-destructive">{error}</p>}

            <Button className="w-full text-xs" onClick={joinRoom}>
              <Mic className="w-3 h-3 mr-2" />
              $ join --voice
            </Button>
            <p className="text-[9px] text-muted-foreground">
              Direct P2P WebRTC. No media server — audio flows peer-to-peer.
            </p>
          </div>
        </div>
      )}

      {/* Connecting */}
      {phase === 'connecting' && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-3">
            <Loader2 className="w-6 h-6 animate-spin mx-auto" style={{ color: '#39FF14' }} />
            <p className="text-xs text-muted-foreground">establishing connection<span className="cursor-blink">_</span></p>
          </div>
        </div>
      )}

      {/* Room */}
      {phase === 'room' && (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Video grid */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className={`grid gap-3 h-full ${peers.length === 0 ? 'grid-cols-1' : peers.length <= 1 ? 'grid-cols-2' : 'grid-cols-2 md:grid-cols-3'}`}>
              {/* Local tile */}
              <VideoTile
                stream={myStream}
                name={`${displayName} (you)`}
                muted={true}
                micEnabled={micEnabled}
                isScreen={screenSharing}
                videoEnabled={camEnabled || screenSharing}
              />
              {/* Remote tiles */}
              {peers.map(p => (
                <VideoTile
                  key={p.id}
                  stream={p.stream}
                  name={p.name}
                  muted={false}
                  micEnabled={true}
                  videoEnabled={true}
                />
              ))}
              {peers.length === 0 && (
                <div className="flex items-center justify-center col-span-full">
                  <div className="text-center space-y-2 opacity-50">
                    <Users className="w-8 h-8 mx-auto text-muted-foreground" />
                    <p className="text-xs text-muted-foreground">Waiting for others to join...</p>
                    <p className="text-[10px] text-muted-foreground">Share this channel link with friends</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="h-16 border-t border-border bg-card flex items-center justify-center gap-3 px-4 flex-shrink-0">
            <ControlBtn
              active={micEnabled}
              onClick={toggleMic}
              icon={micEnabled ? Mic : MicOff}
              label={micEnabled ? 'Mute' : 'Unmute'}
              danger={!micEnabled}
            />
            <ControlBtn
              active={camEnabled}
              onClick={toggleCam}
              icon={camEnabled ? Video : VideoOff}
              label={camEnabled ? 'Stop Video' : 'Start Video'}
            />
            <ControlBtn
              active={screenSharing}
              onClick={toggleScreenShare}
              icon={screenSharing ? MonitorOff : Monitor}
              label={screenSharing ? 'Stop Share' : 'Share Screen'}
              highlight={screenSharing}
            />
            <button
              onClick={leaveRoom}
              className="flex flex-col items-center gap-1 px-3 py-2 rounded transition-colors bg-destructive/20 hover:bg-destructive/40 border border-destructive/40"
            >
              <PhoneOff className="w-4 h-4 text-destructive" />
              <span className="text-[9px] text-destructive">Leave</span>
            </button>
          </div>

          {error && (
            <div className="px-4 py-1 bg-destructive/10 border-t border-destructive/30">
              <p className="text-[10px] text-destructive">{error}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function VideoTile({ stream, name, muted, micEnabled, videoEnabled, isScreen }) {
  const videoRef = useRef(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const hasVideo = stream && stream.getVideoTracks().length > 0 && videoEnabled;

  return (
    <div className="relative rounded border border-border bg-card overflow-hidden flex items-center justify-center" style={{ minHeight: 160 }}>
      {hasVideo ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={muted}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="flex flex-col items-center gap-2">
          <div className="w-12 h-12 rounded-full border border-border flex items-center justify-center text-lg font-bold glow-subtle">
            {(name || '?')[0].toUpperCase()}
          </div>
          <Volume2 className="w-4 h-4 text-muted-foreground animate-pulse" />
        </div>
      )}
      {/* Name tag */}
      <div className="absolute bottom-2 left-2 flex items-center gap-1.5 bg-black/60 rounded px-2 py-0.5">
        {!micEnabled && <MicOff className="w-2.5 h-2.5 text-destructive" />}
        {isScreen && <Monitor className="w-2.5 h-2.5" style={{ color: '#39FF14' }} />}
        <span className="text-[10px] text-white">{name}</span>
      </div>
    </div>
  );
}

function ControlBtn({ active, onClick, icon: Icon, label, danger, highlight }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-3 py-2 rounded transition-colors border ${
        highlight
          ? 'bg-primary/20 border-primary/50 text-primary'
          : danger
          ? 'bg-destructive/10 border-destructive/30'
          : active
          ? 'bg-secondary border-border hover:bg-muted'
          : 'bg-muted/50 border-border hover:bg-secondary'
      }`}
    >
      <Icon className={`w-4 h-4 ${danger && !active ? 'text-destructive' : ''}`} />
      <span className="text-[9px] text-muted-foreground">{label}</span>
    </button>
  );
}