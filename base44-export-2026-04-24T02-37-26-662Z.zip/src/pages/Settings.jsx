const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useUser } from '@/lib/UserContext';
import { useLayout } from '@/lib/LayoutContext';
import { Button } from '@/components/ui/button';
import { LogOut, User, Shield, Monitor, Terminal } from 'lucide-react';

import { useQuery, useQueryClient } from '@tanstack/react-query';

export default function Settings() {
  const { currentUser, isGuest, isMod, logout } = useUser();
  const { chatLayout, setLayout } = useLayout();
  const queryClient = useQueryClient();

  // Mod management (only for mods/admins on servers they manage)
  const { data: allMembers = [] } = useQuery({
    queryKey: ['all-members'],
    queryFn: () => db.entities.ServerMember.list(),
    enabled: isMod && !isGuest,
  });

  const [promotingEmail, setPromotingEmail] = useState('');
  const [promoteStatus, setPromoteStatus] = useState('');

  const handlePromote = async () => {
    if (!promotingEmail.trim()) return;
    const member = allMembers.find(m => m.user_email === promotingEmail.trim());
    if (!member) { setPromoteStatus('User not found in any server'); return; }
    await db.entities.ServerMember.update(member.id, { role: 'mod' });
    queryClient.invalidateQueries({ queryKey: ['all-members'] });
    setPromoteStatus(`✓ ${promotingEmail} promoted to mod`);
    setPromotingEmail('');
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-lg">
      <div className="mb-6">
        <h1 className="text-lg font-bold glow tracking-widest mb-1">SETTINGS</h1>
        <p className="text-xs text-muted-foreground">// user preferences & account</p>
      </div>

      {/* Profile */}
      <div className="border border-border rounded p-4 bg-card space-y-3 mb-4">
        <p className="text-[10px] tracking-widest text-muted-foreground">PROFILE</p>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded border border-border flex items-center justify-center text-sm font-bold glow-subtle">
            {(currentUser?.display_name || currentUser?.full_name || currentUser?.email || '?')[0].toUpperCase()}
          </div>
          <div>
            <p className="text-xs font-bold">
              {currentUser?.display_name || currentUser?.full_name || currentUser?.email}
            </p>
            {!isGuest && currentUser?.email && (
              <p className="text-[10px] text-muted-foreground">{currentUser.email}</p>
            )}
            <div className="flex items-center gap-1 mt-0.5">
              {isGuest ? (
                <span className="text-[9px] text-muted-foreground border border-border px-1 rounded">GUEST</span>
              ) : isMod ? (
                <span className="text-[9px] border px-1 rounded" style={{ color: '#39FF14', borderColor: '#39FF1444' }}>MOD</span>
              ) : (
                <span className="text-[9px] text-muted-foreground border border-border px-1 rounded">MEMBER</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Chat Layout Toggle */}
      <div className="border border-border rounded p-4 bg-card space-y-3 mb-4">
        <p className="text-[10px] tracking-widest text-muted-foreground">CHAT LAYOUT</p>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setLayout('terminal')}
            className={`flex flex-col items-center gap-2 p-3 rounded border transition-colors ${
              chatLayout === 'terminal' ? 'border-primary bg-secondary' : 'border-border hover:bg-secondary'
            }`}
          >
            <Terminal className="w-5 h-5" />
            <span className="text-[10px] tracking-wider">TERMINAL</span>
            <span className="text-[9px] text-muted-foreground">Current style</span>
          </button>
          <button
            onClick={() => setLayout('discord')}
            className={`flex flex-col items-center gap-2 p-3 rounded border transition-colors ${
              chatLayout === 'discord' ? 'border-primary bg-secondary' : 'border-border hover:bg-secondary'
            }`}
          >
            <Monitor className="w-5 h-5" />
            <span className="text-[10px] tracking-wider">DISCORD</span>
            <span className="text-[9px] text-muted-foreground">Bubble style</span>
          </button>
        </div>
      </div>

      {/* Mod management */}
      {isMod && !isGuest && (
        <div className="border border-border rounded p-4 bg-card space-y-3 mb-4">
          <p className="text-[10px] tracking-widest text-muted-foreground flex items-center gap-1">
            <Shield className="w-3 h-3" /> MOD TOOLS
          </p>
          <p className="text-[10px] text-muted-foreground">Promote a member to mod by email:</p>
          <div className="flex gap-2">
            <input
              value={promotingEmail}
              onChange={e => setPromotingEmail(e.target.value)}
              placeholder="user@email.com"
              className="flex-1 bg-background border border-border rounded px-3 py-1.5 text-xs outline-none focus:border-primary"
            />
            <Button size="sm" className="text-xs" onClick={handlePromote}>Promote</Button>
          </div>
          {promoteStatus && <p className="text-[10px]" style={{ color: '#39FF14' }}>{promoteStatus}</p>}
        </div>
      )}

      {/* System Info */}
      <div className="border border-border rounded p-4 bg-card space-y-3 mb-4">
        <p className="text-[10px] tracking-widest text-muted-foreground">SYSTEM INFO</p>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Platform</span>
            <span>THECHATBOX v1.0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Session</span>
            <span>{isGuest ? 'Guest (Anonymous)' : 'Authenticated'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Role</span>
            <span>{isGuest ? 'guest' : isMod ? 'mod' : 'member'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Layout</span>
            <span>{chatLayout}</span>
          </div>
        </div>
      </div>

      {isGuest && (
        <div className="border border-border rounded p-4 bg-card mb-4">
          <p className="text-xs text-muted-foreground mb-2">You're browsing as a guest. Login to:</p>
          <ul className="text-[10px] text-muted-foreground space-y-1 list-none">
            <li>→ Create and join private servers</li>
            <li>→ Save your messages and snippets</li>
            <li>→ Get a permanent username</li>
          </ul>
          <Button className="w-full mt-3 text-xs" onClick={() => window.location.href = window.location.origin}>
            $ ./login.sh
          </Button>
        </div>
      )}

      <Button
        variant="outline"
        className="w-full text-xs border-border hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50"
        onClick={logout}
      >
        <LogOut className="w-3 h-3 mr-2" />
        {isGuest ? '$ exit --guest' : '$ logout'}
      </Button>
    </div>
  );
}