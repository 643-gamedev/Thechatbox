import React, { useState } from 'react';
import Snake from '@/components/games/Snake';
import Minesweeper from '@/components/games/Minesweeper';
import Tetris from '@/components/games/Tetris';
import { Gamepad2 } from 'lucide-react';

const GAMES = [
  { id: 'snake', name: 'Snake', desc: '// classic snake game' },
  { id: 'minesweeper', name: 'Minesweeper', desc: '// find the mines' },
  { id: 'tetris', name: 'Tetris', desc: '// block stacker' },
];

export default function Games() {
  const [active, setActive] = useState(null);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      <div className="h-12 border-b border-border flex items-center px-4 gap-2 bg-card flex-shrink-0">
        <Gamepad2 className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm font-bold glow-subtle">GAMES</span>
        {active && (
          <>
            <span className="text-muted-foreground text-xs">|</span>
            <span className="text-xs text-muted-foreground">{active}</span>
            <button
              onClick={() => setActive(null)}
              className="ml-auto text-[10px] text-muted-foreground hover:text-foreground border border-border px-2 py-0.5 rounded"
            >
              ← back
            </button>
          </>
        )}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {!active && (
          <div className="max-w-md mx-auto space-y-3">
            <p className="text-[10px] tracking-widest text-muted-foreground mb-4">SELECT GAME</p>
            {GAMES.map(g => (
              <button
                key={g.id}
                onClick={() => setActive(g.id)}
                className="w-full flex items-center gap-4 p-4 border border-border rounded bg-card hover:bg-secondary transition-colors text-left group"
              >
                <Gamepad2 className="w-5 h-5 text-muted-foreground group-hover:text-foreground" />
                <div>
                  <p className="text-sm font-bold glow-subtle">{g.name}</p>
                  <p className="text-[10px] text-muted-foreground">{g.desc}</p>
                </div>
              </button>
            ))}
          </div>
        )}
        {active === 'snake' && <Snake />}
        {active === 'minesweeper' && <Minesweeper />}
        {active === 'tetris' && <Tetris />}
      </div>
    </div>
  );
}