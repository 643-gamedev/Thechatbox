import React, { useState } from 'react';
import { Send, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const LANGUAGES = ['python', 'javascript', 'cpp', 'c', 'bash', 'html', 'css', 'rust', 'go', 'java'];

export default function MessageInput({ onSend }) {
  const [content, setContent] = useState('');
  const [isCode, setIsCode] = useState(false);
  const [language, setLanguage] = useState('python');

  const handleSend = () => {
    if (!content.trim()) return;
    onSend({
      content: content.trim(),
      message_type: isCode ? 'code' : 'text',
      code_language: isCode ? language : undefined,
    });
    setContent('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t border-border p-3 bg-card">
      {isCode && (
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] text-muted-foreground">LANG:</span>
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-32 h-7 text-xs bg-background border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-card border-border">
              {LANGUAGES.map(l => (
                <SelectItem key={l} value={l} className="text-xs">{l}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
      <div className="flex items-end gap-2">
        <Button
          variant={isCode ? 'default' : 'outline'}
          size="icon"
          className="h-8 w-8 flex-shrink-0 border-border"
          onClick={() => setIsCode(!isCode)}
        >
          <Code className="w-3.5 h-3.5" />
        </Button>
        <Textarea
          value={content}
          onChange={e => setContent(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isCode ? '// paste your code...' : '> type a message...'}
          className="min-h-[36px] max-h-32 text-xs bg-background border-border resize-none"
          rows={1}
        />
        <Button size="icon" className="h-8 w-8 flex-shrink-0" onClick={handleSend}>
          <Send className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}