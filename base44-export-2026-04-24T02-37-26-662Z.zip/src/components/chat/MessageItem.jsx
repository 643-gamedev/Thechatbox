import React from 'react';

export default function MessageItem({ message, currentUser, layout = 'terminal' }) {
  const myEmail = currentUser?.email || currentUser?.guest_id;
  const isOwn = message.author_email === myEmail;
  const isDiscord = layout === 'discord';

  if (message.message_type === 'code') {
    return (
      <div className={`flex flex-col px-4 py-1 ${isOwn ? 'items-end' : 'items-start'}`}>
        {isDiscord && (
          <span className="text-[10px] text-muted-foreground mb-1">{message.author_name}</span>
        )}
        {!isDiscord && (
          <span className="text-[10px] text-muted-foreground mb-1">
            <span style={{ color: '#39FF14' }}>{message.author_name}</span>
          </span>
        )}
        <div className="max-w-[80%] border border-border bg-card rounded p-2">
          <div className="text-[10px] text-muted-foreground mb-1">{message.code_language}</div>
          <pre className="text-xs text-foreground overflow-x-auto whitespace-pre-wrap">{message.content}</pre>
        </div>
      </div>
    );
  }

  // Discord bubble layout
  if (isDiscord) {
    return (
      <div className={`flex flex-col px-4 py-1 ${isOwn ? 'items-end' : 'items-start'}`}>
        <span className="text-[10px] text-muted-foreground mb-1">{message.author_name}</span>
        <div
          className={`max-w-[75%] px-3 py-2 rounded-2xl text-xs break-words ${
            isOwn
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary border border-border text-foreground'
          }`}
        >
          {message.content}
        </div>
      </div>
    );
  }

  // Terminal layout (default)
  return (
    <div className="px-4 py-0.5 text-xs">
      <span style={{ color: '#39FF1488' }}>[</span>
      <span style={{ color: '#39FF14' }}>{message.author_name}</span>
      <span style={{ color: '#39FF1488' }}>]</span>
      <span className="text-muted-foreground mx-1">$</span>
      <span className="text-foreground break-all">{message.content}</span>
    </div>
  );
}